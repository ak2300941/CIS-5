/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on February 3, 2014, 4:37 PM
 * Project 1 - Survival Text Adventure  
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

//Global Constants

//Function Prototypes
void title(bool &,int &,int &);
void play(int &);
void area1(bool &,short,int &);
void area2(bool &,short &,int &);
void area3(short,int &);
void area4(bool &,short &,int &);
void area5(short,int &);
void area6(bool &,short &,int &);
void area7(int &,bool &,bool &,short &);
void death(bool &,int);
void ending(bool &,short,int,int);


//Execution Begins Here
int main(int argc, char** argv){
    //Declare Variable
    int plocate=0;//Reference for location
    bool runprg=1;//Runs the program, ends if pressed wrong
    bool picka2=0;//Area 2 If item picked up
    bool picka6=0;//Area 6 if item picked up
    bool givea4=0;//Area 4 If supply stolen
    bool kill7=0;//Area 7 if the place fell
    short supply=0;//Supply to score how to end
    int input=0;//Which character it is
    title(runprg,plocate,input);
    do{
        area1(picka2,supply,plocate);
        area2(picka2,supply,plocate);
        area3(supply,plocate);
        area4(givea4,supply,plocate);
        area5(supply,plocate);
        area6(picka6,supply,plocate);
        area7(plocate,runprg,kill7,supply);
        ending(runprg,supply,plocate,input);
        death(runprg,plocate);
    }while(runprg==1);//When runprg==0 it stops;
    return 0;
}


void ending(bool &runprg,short supply,int plocate,int input){
    if(plocate==98&&input==1){
        if(supply==0){
            cout<<"You left the city with no supplies. You died of"<<endl;
            cout<<"hunger when unable to find food in nearby buildings"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>0&&supply<=5){
            cout<<"You took a few supplies on your journey down the road"<<endl;
            cout<<"After weeks of walking you noticed you have no more food left"<<endl;
            cout<<"Few days later..."<<endl;
            cout<<"You see a town in a distance but you couldn't"<<endl;
            cout<<"walk no longer, you fell and slowly died of hunger."<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>5){
            cout<<"You had readied yourself for a long journey down the road"<<endl;
            cout<<"Weeks has passed.... as you gathered for supplies anytime you can"<<endl;
            cout<<"In a distance you see a town with farms being taken care of."<<endl;
            cout<<"You slowly introduced yourself as non threatening as you can"<<endl;
            cout<<"They welcomed you into their town"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
    }
    if(plocate==98&&input==2){
        if(supply==0){
            cout<<"You left the city with no supplies. You ran as fast"<<endl;
            cout<<"as you can. Having the ability to run didn't help at all."<<endl;
            cout<<"When unable to run no more, your body gave up and you fell"<<endl;
            cout<<"and died of hunger"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>0&&supply<=5){
            cout<<"You took a few supplies on your journey down the road"<<endl;
            cout<<"After weeks of running day after day you noticed you"<<endl;
            cout<<"have no more food left"<<endl;
            cout<<"Few days later..."<<endl;
            cout<<"You see a town in a distance but you couldn't"<<endl;
            cout<<"move after losing all your energy, you fell and slowly died of hunger."<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>5){
            cout<<"You had readied yourself for a long journey down the road"<<endl;
            cout<<"A week has passed....."<<endl;
            cout<<"In a distance you see a town with farms being taken care of."<<endl;
            cout<<"You slowly introduced yourself as non threatening as you can"<<endl;
            cout<<"They welcomed you into their town"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
    }
}

void death(bool &runprg,int plocate){
    if(plocate==99){
        cout<<"You have died"<<endl;
        cout<<"Game Over"<<endl;
        runprg=0;
    }
}

void area7(int &plocate,bool &runprg,bool &kill7,short &supply){
    unsigned int input=0;
    if(plocate==7){
        if(kill7==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"As you walk along the road you can feel the ground shaking"<<endl;
            cout<<"What will you do"<<endl;
            cout<<"1. Back away"<<endl;
            cout<<"2. Run forward"<<endl;
            cin>>input;
            if(input==1){
                cout<<"You can see the road ahead breaking apart from"<<endl;
                cout<<"a rupture in the ground. If you had went across"<<endl;
                cout<<"you would have fallen to your death"<<endl;
                cout<<endl;
                kill7=1;plocate=7;
            }
            else if(input==2){
                cout<<"You try to run across but the cracks on the road"<<endl;
                cout<<"falls apart and you fell to your death"<<endl;
                plocate=99;
            }
        }
        else if(kill7==1){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You looked at the wreckage in front of you."<<endl;
            cout<<"Decided the road in front is impassable"<<endl;
            cout<<"1. Turn Back"<<endl;
            cin>>input;
            cout<<endl;
            if(input==1)plocate=5;
        }
    }
}

void area6(bool &picka6,short &supply,int &plocate){
    long input1=0;//For the inputs
    if(plocate==6){
        if(picka6==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"After coming out of the roots, you see a chest"<<endl;
            cout<<"1. Try to open Chest (Get 6 supplies)"<<endl;
            cout<<"2. Go back"<<endl;
            cout<<endl;
            cin>>input1;
            if(input1==1){
                cout<<"Chest is locked try giving it a few kicks (3)"<<endl;
                cout<<"1. Kick"<<endl;
                for(int i=0;i<3;i++){
                    cin>>input1;
                    if(input1==1){
                        cout<<"Kicked"<<endl;
                    }
                }
                supply=supply+6;
                picka6=1;
            }
            else if(input1==2)plocate=3;
        }
        else if(picka6==1){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You looked around for any other hidden supplies."<<endl;
            cout<<"The place seems cleaned out"<<endl;
            cout<<"1. Go back"<<endl;
            cout<<endl;
            cin>>input1;
            if(input1==1)plocate=3;
        }
    }
}


void area5(short supply,int &plocate){
    unsigned long input=0;//For the inputs
    if(plocate==5){
        cout<<"Your current supply = "<<supply<<endl;
        cout<<"You find the road which leads out of the city"<<endl;
        cout<<"Are you sure you wanna leave now?"<<endl;
        cout<<"1. Leave the city (Ends)"<<endl;
        cout<<"2. Go South"<<endl;
        cout<<"3. Turn around"<<endl;
        cout<<endl;
        cin>>input;
        if(input==1)plocate=98;
        else if(input==2)plocate=7;
        else if(input==3)plocate=3;
    }
}

void area4(bool &givea4,short &supply,int &plocate){
    unsigned short input=0;//For the inputs from 0 - 65535
    const unsigned short DEMAND=2;//Always demands 2 supplies in this function
    if(plocate==4){
        if(givea4==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"There stands a member of a gang, He wants your supplies"<<endl;
            cout<<"He demands 2 supplies if you don't you will die"<<endl;
            cout<<"1. Give 2 supplies"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1){
                supply=supply-DEMAND;
                givea4=1;
            }
            if(supply<2){
                cout<<"You didn't have enough supplies, you have been shot to"<<endl;
                cout<<"death."<<endl;
                plocate=99;
            }
        }
        else if(givea4==1){
            cout<<"Supply remaining = "<<supply<<endl;
            cout<<"After giving away your supply he seems to let you live"<<endl;
            cout<<"You looked around and you see the area blocked with no"<<endl;
            cout<<"other way out so you turned around"<<endl;
            cout<<"1. Go back"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1)plocate=3;
        }
    }
}

void area3(short supply,int &plocate){
    int input=0;//For the inputs
    while(plocate==3){
        cout<<"Your current supply = "<<supply<<endl;
        cout<<"The path to the north of you is blocked by a giant root"<<endl;
        cout<<"1. Go South"<<endl;
        cout<<"2. Go West"<<endl;
        cout<<"3. Go Back"<<endl;
        cout<<"4. Take a closer look at the root towards the North"<<endl;
        cout<<endl;
        cin>>input;
        if(input==1)plocate=4;
        else if(input==2)plocate=5;
        else if(input==3)plocate=1;
        else if(input==4){
            cout<<"Upon closer inspection with the root you find a way through"<<endl;
            plocate=6;
        }
    }
}

void area2(bool &picka2,short &supply,int &plocate){
    int input=0;//For the inputs
    float x=294.23;
    if(plocate==2){
        if(picka2==0){//Not picked up supply
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"As you continue to walk you find out this is a deserted city"<<endl;
            cout<<"You reached an area which is blocked off by boulders."<<endl;
            cout<<"The boulders has graffiti marks which reads "<<setprecision(2)<<fixed<<x<<endl;
            cout<<"It seems to be random graffiti markings"<<endl;
            cout<<"Some supplies are found beside the boulders"<<endl;
            cout<<"1. Head Back"<<endl;
            cout<<"2. Pick up Supplies (+5)"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1)plocate=1;
            else if(input==2){
                cout<<"You picked up some supplies which were hidden"<<endl;
                supply=supply+5;
                picka2=1;//Item Picked up
            }
        }
        else if(picka2==1){//When item is picked up go to this block
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"The boulder still block the path"<<endl;
            cout<<"1. Head Back"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1)plocate=1;
        }
    }
}

void area1(bool &picka2,short supply,int &plocate){//First area
    int input=0;//For the inputs
    if(plocate==1){
        do{
            cout<<"Your current supply = "<<supply<<endl;     
            cout<<"You are standing around buildings which seems to be deserted."<<endl;
            cout<<"You look around the path it seems to only go North or West"<<endl;
            cout<<"1. Go North"<<endl;
            cout<<"2. Go West"<<endl;
            cout<<endl;
            cin>>input;
            switch(input){
            case 1:     plocate=2;break;
            case 2:     plocate=3;break;
            }
        }       while(plocate==1);
    }
}

void play(int &input){
    string line;
    ifstream myfile("readinme.txt");
    if(myfile.is_open()){
        while(getline(myfile,line)){
            cout<<line<<endl;
        }
        myfile.close();
    }
    cin>>input;
    return;
}

void title(bool &runprg,int &plocate,int &input){
    char p=80;//char p=80 is P
    cout<<setw(20)<<"Survival Text Adventure"<<endl;//Sets Format
    cout<<endl;
    cout<<endl;
    cout<<"1. "<<p<<"lay"<<endl;
    cout<<"2. Exit"<<endl;
    cin>>input;
    if(input==1){
        play(input);//Starts the game
        plocate=1;//Sends to starting area
    }
    else{
        runprg=0;//exits
    }
    return;
}
