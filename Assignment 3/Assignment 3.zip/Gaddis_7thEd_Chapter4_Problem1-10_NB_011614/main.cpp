/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 16, 2014, 10:24 AM
 * Gaddis 8thEd Chapter 4 Problem 1-10
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //General Menu Format
    bool loop=true;
    do{
        //Display the selection
        cout<<"Type 1 to solve problem 1"<<endl;
        cout<<"Type 2 to solve problem 2"<<endl;
        cout<<"Type 3 to solve problem 3"<<endl;
        cout<<"Type 4 to solve problem 4"<<endl;
        cout<<"Type 5 to solve problem 5"<<endl;
        cout<<"Type 6 to solve problem 6"<<endl;
        cout<<"Type 7 to solve problem 7"<<endl;
        cout<<"Type 8 to solve problem 8"<<endl;
        cout<<"Type 9 to solve problem 9"<<endl;
        cout<<"Type 10 to solve problem 10"<<endl;
        cout<<"Type anything else to quit with no solutions."<<endl;
        //Read the choice
        int choice;
        cin>>choice;
        //Solve a problem that has been chosen.
        switch(choice){
                case 1:{
                    //Declare Variable
                    float x,y;
                    //Input 2 Numbers to compare
                    cout<<"Enter 2 inputs to compare which is greater"<<endl;
                    cin>>x>>y;
                    //Use conditional operator to find which number is greater/smaller
                    x>y?cout<<x<<" is greater than "<<y//(x>y) True
                    :cout<<y<<" is greater than "<<x<<endl;//Else
                    break;
                }
                case 2:{
                    //Declare Variable
                    int x;
                    //Enter a number between 1 to 10
                    cout<<"Input a number from 1 to 10 to change"<<endl;
                    cout<<"to a roman numeral"<<endl;
                    cin>>x;
                    switch(x){
                        case 1:cout<<"I"<<endl;
                                break;
                        case 2:cout<<"II"<<endl;
                                break;
                        case 3:cout<<"III"<<endl;
                                break;
                        case 4:cout<<"IV"<<endl;
                                break;
                        case 5:cout<<"V"<<endl;
                                break;        
                        case 6:cout<<"VI"<<endl;
                                break;
                        case 7:cout<<"VII"<<endl;
                                break;        
                        case 8:cout<<"VIII"<<endl;
                                break;       
                        case 9:cout<<"IX"<<endl;
                                break;
                        case 10:cout<<"X"<<endl;
                                break;
                        default:cout<<"You did not enter 1-10"<<endl;          
                    }    
                    break;
                }
                case 3:{
                    //Declare Variable
                    int day,month,year;
                    //Enter the day, month, and year in numeric form
                    cout<<"Enter the day"<<endl;
                    cin>>day;
                    cout<<"Enter the month in numeric form"<<endl;
                    cin>>month;
                    cout<<"Enter the 2 digit year"<<endl;
                    cin>>year;
                    //Day*Month=Year if true its magic
                    if(day*month==year){
                        cout<<"The date is magic"<<endl;
                    }    
                    else{
                        cout<<"The date is not magic"<<endl;
                    }   
                    break;
                }
                case 4:{
                    //Declare Variable
                    float l1,l2,w1,w2,a1,a2;
                    //Input the length and width of first rectangle
                    cout<<"What is the length and width"<<endl;
                    cout<<"of the first rectangle?"<<endl;
                    cin>>l1>>w1;
                    //Input the length and width of the second rectangle
                    cout<<"What is the length and width"<<endl;
                    cout<<"of the second rectangle?"<<endl;
                    cin>>l2>>w2;
                    //Calculate the area
                    a1=l1*w1;
                    a2=l2*w2;
                    //Greater area or equal?
                    if(a1>a2){
                        cout<<"Area of the first rectangle is greater"<<endl;
                        cout<<"than the second rectangle"<<endl;
                    }
                    else if(a2>a1){
                        cout<<"Area of the second rectangle is greater"<<endl;
                        cout<<"than the first rectangle"<<endl;
                    }
                    else if(a1==a2){
                        cout<<"Areas of both triangles are the same"<<endl;
                    }
                    break;
                }    
                case 5:{
                    //Declare Variables
                    float w,h,bmi,a,b;
                    //Input the Weight (lbs)
                    cout<<"Weight in pounds"<<endl;
                    cin>>w;
                    //Input Height (inches)
                    cout<<"Height in inches"<<endl;
                    cin>>h;
                    //Calculate BMI
                    bmi=(w*703)/(h*h);
                    //Display BMI
                    cout<<"BMI is "<<bmi<<endl;
                    //Program when BMI is overweight, underweight and optimal
                    if(bmi<=25&&bmi>=18.5){
                        cout<<"BMI is optimal for a sedentary person"<<endl;
                    }
                    else if(bmi<18.5){
                        cout<<"BMI shows you are underweight"<<endl;
                        cout<<"for a sedentary person"<<endl;
                    }
                    else if(bmi>25){
                        cout<<"BMI shows you are overweight"<<endl;
                        cout<<"for a sedentary person"<<endl;
                    }
                    break;
                 }   
                 case 6:{
                    //Declare Variables
                    float weight,mass;
                    //Input object's mass
                    cout<<"What is the mass of the object?"<<endl;
                    cin>>mass;
                    //Calculate Weight (newtons)
                    weight=mass*9.8;
                    //Display Weight in Newtons
                    cout<<"Weight is "<<weight<<" newtons"<<endl;
                    //Program when its too heavy or too light
                    if(weight>1000){
                        cout<<"Object is too heavy"<<endl;
                    }
                    else if(weight<10){
                        cout<<"Object is too light"<<endl;
                    }
                    break;
                 }   
                 case 7:{
                    //Declare Variables
                    int sec,min,hour,day,imin=0,ihour=0,iday=0;
                    //Input Seconds
                    cout<<"Enter number of seconds"<<endl;
                    cin>>sec;
                    //Calculate seconds to minutes, hours and days
                    min=60;
                    hour=3600;
                    day=86400;
                    //Input should convert to min, hour or day if possible
                    if(day<=sec){
                        (iday=sec/day);sec%=day;//sec=sec%day
                    }
                    if(hour<=sec){
                        (ihour=sec/hour);sec%=hour;//sec=sec%hour
                    }
                    if(min<=sec){
                        (imin=sec/min);sec%=min;// sec=sec%min
                    }
                    //Display Result
                        cout<<iday<<" days, "<<ihour<< " hours, "<<imin<<" minutes, and "<<sec<<" seconds"<<endl;
                    break;  
                 }   
                 case 8:{
                    //Declare Variables
                     float pen,ipen,nick,inick,dime,idime,quart,iquart,doll,tot;
                     quart=25;
                     dime=10;
                     nick=5;
                     pen=1;
                     doll=100;
                     //# of Quarters, Dimes, Nickels and Pennies
                     cout<<"Enter the number of quarters"<<endl;
                     cin>>iquart;
                     cout<<"Enter the number of dimes"<<endl;
                     cin>>idime;
                     cout<<"Enter the number of nickels"<<endl;
                     cin>>inick;
                     cout<<"Enter the number of pennies"<<endl;
                     cin>>ipen;
                     //Calculate Value
                     tot=(quart*iquart)+(dime*idime)+(nick*inick)+(pen*ipen);
                     //Program to see if it was exactly one dollar or not
                     if(tot==doll){
                         cout<<"Congratulations you have won the game"<<endl;
                     }
                     if(tot>doll){
                         cout<<"Sorry the amount is over one dollar"<<endl;
                     }    
                     if(tot<doll){
                         cout<<"Sorry the amount is less than one dollar"<<endl;
                     }       
                    break;
                 }
                 case 9:{
                    //Declare Variables
                    int a,b,c,ans;
                    //Random Problem Generate, Calculation
                    a=1+rand()%350;
                    b=1+rand()%350;
                    c=a+b;
                    cout<<a<<"+"<<b<<"="<<endl;
                    cin>>ans;
                    if(ans==c){
                        cout<<"Congratulations the answer is correct"<<endl;
                    }
                    else{
                        cout<<"Answer is incorrect"<<endl;
                        cout<<"The correct answer is "<<c<<endl;
                    }            
                    break;
                 }
                 case 10:{
                    //Declare Variables
                    int unit,val,d1,d2,d3,d4,it1,it2,it3,it4;
                    //Enter quantity sold
                    cout<<"Number of units sold? (Greater than 0)"<<endl;
                    cin>>unit;
                    val=unit*99;
                    //Calculate total cost
                    if(unit>=10&&unit<=19){
                       d1=val*.2;
                       it1=val-d1;
                    }
                    else if(unit<10&&unit>=0){
                        it1=val;
                    }
                    else if(unit>=20&&unit<=49){
                        d2=val*.3;
                        it1=val-d2;
                    }
                    else if(unit>=50&&unit<=99){
                        d3=val*.4;
                        it1=val-d3;
                    } 
                    else if(unit>=100){
                        d4=val*.5;
                        it1=val-d4;
                    }
                    //Display Result
                    cout<<"Number of units sold is "<<unit<<endl;
                    cout<<"Total cost is $"<<it1<<endl;
                    break;
                 }
                default:{
                        cout<<"Exit?"<<endl;
                        loop=false;
                        break;
                }
        };
    }while(loop);//Upper do-while
    return 0;
}

