/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 8:43 PM
 * Calculate how many calories consumed
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float cooke, calor, persev,percok;
    //Total Eaten cookies
    cout<<"How many cookies did you eat"<<endl;
    cin>>cooke;
    //Calculate how many calories from the input
    persev=40/10;
    percok=300/persev;
    calor=percok*cooke;
    //Display Resulting Calories eaten
    cout<<"The total calories consumed is "<<calor<<endl;
    //Exit Stage Right
    return 0;
}

