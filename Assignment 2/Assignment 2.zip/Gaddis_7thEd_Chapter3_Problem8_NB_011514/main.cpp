/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 8:21 PM
 * Find 80% of repair amount, then display
 * min. amount of insurance he or she should buy
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constant

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float recost,save;
    //Ask for replacement cost
    cout<<"What is the replacement cost?"<<endl;
    cin>>recost;
    //Calculate 80% of the repair cost
    save=recost*.8;
    //Display how much insurance that is recommended
    cout<<"The minimum amount of insurance needed is $"<<save<<endl;
    //Exit Stage Right
    return 0;
}

