/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 11:33 AM
 * Find Average from 3 Inputs
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float avg,r1,r2,r3;
    //Declare String
    string mon1,mon2,mon3;
    //Name of each month
    cout<<"What are the 3 month you are "<<endl; 
    cout<<"trying to calculate the average? "<<endl;
    cin>>mon1>>mon2>>mon3;
    //Input the amount of rain (in) that fell each month)
    cout<<"How much rain fell in inches in "<<mon1<<", "<<mon2<<", "<<"and "<<mon3<<"?"<<endl;
    cin>>r1>>r2>>r3;
    //Calculate the Average
    avg=(r1+r2+r3)/3;
    //Display the Average
    cout<<"The average rainfall for"<<endl;
    cout<<mon1<<", "<<mon2<<", and "<<mon3<<" is "<<setprecision(2)<<avg<<"inches"<<endl;
    //Exit Stage Right
    return 0;
}

