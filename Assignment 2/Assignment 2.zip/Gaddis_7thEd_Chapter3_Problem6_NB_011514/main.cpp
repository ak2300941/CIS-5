/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 8:09 PM
 * Finding how many widget are stacked
 * by inputting the total weight
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float tot,pallet,wid;
    //How much does the pallet weight by itself
    cout<<"How much does the pallet weigh?"<<endl;
    cin>>pallet;
    //Input Total Weight
    cout<<"What is the total weight "<<endl;
    cin>>tot;
    //Calculate how many widgets are stacked on top of the pallet
    wid=(tot-pallet)/9.2;
    //Display Result
    cout<<"The # of widget stacked is "<<setprecision(2)<<fixed<<wid<<endl;
    //Exit Stage Right
    return 0;
}

