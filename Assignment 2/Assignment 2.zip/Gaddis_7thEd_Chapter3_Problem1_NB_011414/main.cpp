/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 14, 2014, 7:32 AM
 * Calculate a car's gas mileage
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mpg,galgas,mtank;
    //Input how many gallon of gas a car can hold and the number of miles
    //it can be driven on a full tank
    cout<<"What is the number of gallons a car can hold and how many miles"
        <<" it can be driven on a full tank"<<endl;
    cin>>galgas>>mtank;
    //Calculate Miles Per Gallon
    mpg=mtank/galgas;
    //Display MPG
    cout<<"MPG is "<<mpg<<endl;
    //Exit Stage Right
    return 0;
}