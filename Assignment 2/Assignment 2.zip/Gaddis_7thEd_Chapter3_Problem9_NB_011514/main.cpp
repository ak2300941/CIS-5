/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 9:00 PM
 * Total up the cost monthly and annually
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variable
    float loan,insur,gas,oil,tire,maint,month,year;
    //Input monthly cost of each item
    cout<<"What is the monthly cost for loan payments?"<<endl;//Loan
    cin>>loan;
    cout<<"What is the monthly cost for insurance payments?"<<endl;//Insurance
    cin>>insur;
    cout<<"What is the monthly cost for gas payments?"<<endl;//Gas
    cin>>gas;
    cout<<"What is the monthly cost for oil payments?"<<endl;//Oil
    cin>>oil;
    cout<<"What is the monthly cost for tires payments?"<<endl;//Tires
    cin>>tire;
    cout<<"What is the monthly cost for maintenance payments?"<<endl;//Maintenance
    cin>>maint;
    //Find the total monthly cost
    month=loan+insur+gas+oil+tire+maint;
    //Find the total yearly cost
    year=month*12;
    //Display Results
    cout<<"The total monthly cost is $"<<setprecision(2)<<fixed<<month<<endl;
    cout<<"The total yearly cost is  $"<<year<<endl;
    //Exit Stage Right
    return 0;
}

