/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 7:21 PM
 * Calculate theater gross and net box profit
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float atiket,ctiket,gross,netbox,distrib;
    //Declare String
    string movie;
    //Input name of the movie
    cout<<"What is the name of the movie?"<<endl;
    std::getline (std::cin,movie);
    //Ticket Sold Adult and then Children
    cout<<"How many ticket sold to adults?"<<endl;
    cin>>atiket;
    cout<<"How many ticket sold to children?"<<endl;
    cin>>ctiket;
    //Calculate Gross Box Office Profit
    gross=(atiket*6)+(ctiket*3);
    //Net Box Office Profit
    netbox=gross*.2;
    //Amount paid to distributor
    distrib=gross-netbox;
    //Display All
    cout<<"Movie Name:                    "<<setw(4)<<movie<<endl;
    cout<<"Adult Tickets Sold:               "<<atiket<<endl;
    cout<<"Child Tickets Sold:               "<<ctiket<<endl;
    cout<<"Gross Box Office Profit:       $"<<setprecision(2)<<fixed<<gross<<endl;
    cout<<"Net Box Office Profit:          $"<<netbox<<endl;
    cout<<"Amount Paid to Distributor:    $"<<distrib<<endl;
    //Exit Stage Right

    return 0;
}

