/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 14, 2014, 8:23 PM
 * Calculating income generated from
 * seats sold at the stadium
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float classa,classb,classc,tot;
    //Input amount of Class A, B, and C ticket sold in that order
    cout<<"How many tickets were sold in Class A, B and C"<<endl;
    cout<<"in that order?"<<endl;
    cin>>classa>>classb>>classc;
    //Format Precision, Fixed
    cout<<setprecision(2)<<fixed<<endl;
    //Calculate the profit from Class A, B, and C individually
    cout<<"Class A profit is $"<<classa*15<<endl;
    cout<<"Class B profit is  $"<<classb*12<<endl;
    cout<<"Class C profit is  $"<<classc*9<<endl;
    //Calculate amount of income generated from ticket sales
    tot=(classa*15)+(classb*12)+(classc*9);
    //Display the income generated (Fixed-point, 2 Decimal Places)
    cout<<"Profit made is    $"<<tot<<endl;
    //Exit Stage Right
    return 0;
}

