/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 14, 2014, 8:42 PM
 * Test Average
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float t1,t2,t3,t4,t5,avg;
    //Input all 5 test scores
    cout<<"Type in all 5 test scores "<<endl;
    cin>>t1>>t2>>t3>>t4>>t5;
    //Calculate the average
    avg=(t1+t2+t3+t4+t5)/5;
    //Display Result
    cout<<"The average test score is "<<setprecision(1)<<fixed<<avg<<endl;
    //Exit Stage Right
    return 0;
}

