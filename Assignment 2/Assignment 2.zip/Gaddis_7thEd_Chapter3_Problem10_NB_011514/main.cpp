/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 15, 2014, 9:11 PM
 * Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float cels,farh,mid;
    //Input Celsius
    cout<<"Input the degree in Celsius in which to convert"<<endl;
    cin>>cels;
    //Calculation to convert
    mid=1.8*cels;
    farh=mid+32;
    //Display Result
    cout<<"The Fahrenheit is "<<farh<<" degrees"<<endl;
    //Exit Stage Right
    return 0;
}

