/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on February 4, 2014, 9:59 AM
 */

//System Libraries
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

//Global Constants

//Function Prototypes
void bubble (vector<int> &,int );
void filVec (vector<int> &,int);
void prntVec (const vector<int> &, int);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Open a file to record the data
    ofstream output;
    output.open("TimeStudy.dat");
    //Declare Variable and initialize the random number
    const int SIZE=150000;
    vector<int> array;
    srand(static_cast<unsigned short>(time(0)));
    //Fill the array
    filVec (array,SIZE);
    //Bubble Sort
    for(int size=10000;size<SIZE;size+=10000){
        int strTime=time(0);
        bubble(array,size);
        int endTime=time(0);
        cout<<"Total Time Taken = "<<endTime-strTime
                <<" secs for array size = "<<size<<endl;
        output<<size<<" "<<endTime-strTime<<endl;
    }
    output.close();
    return 0;
}
void bubble (vector<int> &a,int n){
    bool swap;
    int temp;
    do{
          swap=false;
          for (int count=0;count<(n-1);count++){
              if (a[count]>a[count+1]){
                  temp=a[count];
                  a[count]=a[count+1];
                  a[count+1]=temp;
                  swap=true;
              }
          }
    } while (swap); 
}

void prntVec (const vector<int> &a, int perline){
    cout<<endl;
    for(int i=0;i<a.size();i++){
        cout<<a[i]<<" ";
        if (i%10==(perline-1))
            cout<<endl;
    }
}

void filVec (vector<int> &a,int n){
    for (int i=0;i<n;i++){
        a.push_back(rand()%90+10);
    }
    
}