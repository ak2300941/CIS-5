/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on February 4, 2014, 11:02 AM
 */

//System Libraries
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

//Global Constants

//Function Prototypes
void selsort (vector<int> &,int );
void filVec (vector<int> &,int);
void prntVec (const vector<int> &, int);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Open a file to record the data
    ofstream output;
    output.open("TimeStudy.dat");
    //Declare Variable and initialize the random number
    const int SIZE=150000;
    vector<int> array;
    srand(static_cast<unsigned short>(time(0)));
    //Fill the array
    filVec (array, SIZE);
    //Selection Sort
    for(int size=10000;size<SIZE;size+=10000){
        int strTime=time(0);
        selsort (array,size);
        int endTime=time(0);
        cout<<"Total Time Taken = "<<endTime-strTime
                <<" secs for array size = "<<size<<endl;
        output<<size<<" "<<endTime-strTime<<endl;
    }
    output.close();
    return 0;
}


void selsort (vector<int> &a,int n){
    int mIndex, strscan, mValue;
    for (strscan=0;strscan<(n-1);strscan++){
        mIndex=strscan;
        mValue=a[strscan];
        for (int index=(strscan+1);index<n;index++){
            if (a[index]<mValue){
                mValue=a[index];
                mIndex=index;
            }
        }
        a[mIndex]=a[strscan];
        a[strscan]=mValue;
    }
}

void prntVec (const vector<int> &a, int perline){
    cout<<endl;
    for(int i=0;i<a.size();i++){
        cout<<a[i]<<" ";
        if (i%10==(perline-1))
            cout<<endl;
    }
}

void filVec (vector<int> &a,int n){
    for (int i=0;i<n;i++){
        a.push_back(rand()%90+10);
    }
    
}