/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 16, 2014, 10:24 AM
 * Gaddis 8thEd Chapter 4 Problem 1-10
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <cmath>
using namespace std;

//Global Constants

//Function Prototypes
void calculateRetail(float, float, float);
float getLength(float);
float getWidth(float);
float getArea(float, float);
float displayArea(float, float, float);
float getSales(float);
void findHighest(float, float, float, float);
int getNumAccidents(int);
void findLowest(int, int, int, int, int);
float fallingDistance(float);
float kineticEnergy(float, float);
float celsius(float);
short coinToss(short);
float presentValue(float, float, float);
void getScore(float &score);
void calcAverage(float, float, float, float, float, float);
float findLowest(float, float, float, float, float);
//Execution Begins Here

int main(int argc, char** argv) {
    //General Menu Format
    bool loop = true;
    do {
        //Display the selection
        cout << "Type 1 to solve problem 1" << endl;
        cout << "Type 2 to solve problem 2" << endl;
        cout << "Type 3 to solve problem 3" << endl;
        cout << "Type 4 to solve problem 4" << endl;
        cout << "Type 5 to solve problem 5" << endl;
        cout << "Type 6 to solve problem 6" << endl;
        cout << "Type 7 to solve problem 7" << endl;
        cout << "Type 8 to solve problem 8" << endl;
        cout << "Type 9 to solve problem 9" << endl;
        cout << "Type 10 to solve problem 10" << endl;
        cout << "Type 11 to solve problem 11" << endl;
        cout << "Type 12 to solve problem 12" << endl;
        cout << "Type 13 to solve problem 13" << endl;
        cout << "Type 14 to solve problem 14" << endl;
        cout << "Type 15 to solve problem 15" << endl;
        cout << "Type 16 to solve problem 16" << endl;
        cout << "Type 17 to solve problem 17" << endl;
        cout << "Type 18 to solve problem 18" << endl;
        cout << "Type 19 to solve problem 19" << endl;
        cout << "Type 20 to solve problem 20" << endl;
        cout << "Type anything else to quit with no solutions." << endl;
        //Read the choice
        int choice;
        cin >> choice;
        //Solve a problem that has been chosen.
        switch (choice) {
            case 1:
            {
                //Declare Variables
                int num, start = 1, sum = 0;
                //Input Positive Integer Value
                cout << "Enter a Positive Integer Value" << endl;
                cin >> num;
                //Error if Negative
                while (num < 0) {
                    cout << "This is not a positive integer value" << endl;
                    cin >> num;
                }
                while (start <= num) { //Loops til start<=num is false
                    sum += start; //sum=sum+start           
                    start++; //start value +1
                }
                //Display Result
                cout << "Sum of " << num << " is " << sum << endl;
                break;
            }
            case 2:
            {
                //Declare Variables
                int count = 1; //Counter starts at 1
                //Program below needs character letters from 1-127, Letter&Counter +1 each loop
                for (char letter = 1; letter < 127; letter++, count++) { //Use char to get ASCII code  
                    if (count == 16) { //Formats 16 Characters Each Line                         
                        count = 0;
                        cout << endl;
                    }
                    cout << letter; //Letter keeps counting upwards in ASCII code
                } //Letter 1-32 is unprintable
                cout << endl;
                break;
            }
            case 3:
            {
                //Declare Variables
                float level;
                //Format
                cout << "Year" << setw(9) << "Risen" << endl;
                cout << setprecision(2) << fixed << showpoint << endl;
                //Loop
                for (float year = 1; year < 26; year++) {
                    //Calculation of Ocean Levels
                    level = year * 1.5;
                    cout << year << setw(10) << level << "mm" << endl;
                }
                break;
            }
            case 4:
            {
                //Declare  Variables
                float cal;
                //Loop
                for (float min = 10; min <= 30; min += 5) {
                    //Calculation for burning calories 
                    cal = min * 3.9;
                    cout << cal << endl;
                }
                cout << endl;
                break;
            }
            case 5:
            {
                //Declare Variables
                float fees = 2500;
                //Format
                cout << setprecision(2) << fixed;
                for (int yrs = 1; yrs <= 6; yrs++) {
                    //Calculation of fee increase
                    fees = (fees * .04) + fees; //(2500*.04)+2500=(Stored Fees)
                    cout << "Fees of the year " << yrs << " is $" << fees << endl;
                }
                break;
            }
            case 6:
            {
                //Declare Variables
                int mph, hr;
                //Input speed of car
                cout << "What is the speed of the vehicle in mph? ";
                cin >> mph; //Wants this format

                //Input hours traveled
                cout << "How many hours has it traveled? ";
                cin >> hr; //Wants this format
                //Format
                cout << "Hour   Distance Traveled" << endl;
                cout << "----------------------------" << endl;
                //Loop
                for (int hrs = 1; hrs <= hr; hrs++) {
                    //Calculations for distance
                    int dist;
                    dist = mph*hrs;
                    cout << hrs << setw(15) << dist << endl;
                }
                break;
            }
            case 7:
            {
                //Declare Variables
                int days, pen = 1, tot = 0;
                //Input # of days
                cout << "Number of Days ";
                cin >> days;
                //Don't Accept Input less than 1
                while (days < 1) {
                    cout << "Can't accept numbers less than 1" << endl;
                    cin >> days;
                }
                cout << 1 << endl; //Display the first day
                //Loop
                for (int day = 1; day <= days - 1; day++) {
                    //Calculate
                    pen += pen; //pen=pen+pen
                    tot = pen;
                    cout << pen << endl;
                }
                break;
            }
            case 8:
            {
                //Declare Variable
                float a, b, c, ans; //made float because of division
                //Random Problem Generate, Calculation
                bool loop = true;
                do {
                    //Display the selection
                    cout << "Type 1 to solve problem with addition" << endl;
                    cout << "Type 2 to solve problem with subtraction" << endl;
                    cout << "Type 3 to solve problem with multiplication" << endl;
                    cout << "Type 4 to solve problem with division" << endl;
                    cout << "Type anything else to quit." << endl;
                    //Read the choice
                    //Initialize the random number seed
                    a = 1 + rand() % 10 + 1;
                    b = 1 + rand() % 10 + 1;
                    int choice;
                    cin >> choice;
                    //Solve a problem that has been chosen.
                    switch (choice) {
                        case 1:
                        {
                            //Addition
                            c = a + b;
                            cout << a << "+" << b << "=" << endl;
                            cin >> ans;
                            if (ans == c) {
                                cout << "Congratulations the answer is correct" << endl;
                            } else {
                                cout << "Answer is incorrect" << endl;
                                cout << "The correct answer is " << c << endl;
                            }
                            break;
                        }
                        case 2:
                        {
                            //Subtraction
                            c = a - b;
                            cout << a << "-" << b << "=" << endl;
                            cin >> ans;
                            if (ans == c) {
                                cout << "Congratulations the answer is correct" << endl;
                            } else {
                                cout << "Answer is incorrect" << endl;
                                cout << "The correct answer is " << c << endl;
                            }
                            break;
                        }
                        case 3:
                        {
                            //Multiplication
                            c = a*b;
                            cout << a << "x" << b << "=" << endl;
                            cin >> ans;
                            if (ans == c) {
                                cout << "Congratulations the answer is correct" << endl;
                            } else {
                                cout << "Answer is incorrect" << endl;
                                cout << "The correct answer is " << c << endl;
                            }
                            break;
                        }
                        case 4:
                        {
                            //Division
                            c = a / b;
                            cout << a << "/" << b << "=" << endl;
                            cin >> ans;
                            if (ans == c) {
                                cout << "Congratulations the answer is correct" << endl;
                            } else {
                                cout << "Answer is incorrect" << endl;
                                cout << "The correct answer is " << c << endl;
                            }
                            break;
                        }
                        default:
                        {
                            cout << "Exit?" << endl;
                            loop = false;
                            break;
                        }
                    };
                } while (loop); //Upper do-while
                break;
            }
            case 9:
            {
                //Declare Variables
                int floor = 0, room = 0, numocc = 0, totuo = 0;
                float rate, totr = 0, toto = 0;
                //How many floors do hotel have?
                cout << "How many floors does the hotel have?" << endl;
                cin >> floor;
                //Loop
                for (int flor = 1; flor <= floor; flor++) {
                    //How many rooms in this floor?
                    cout << "How many rooms in  floor " << flor << "?" << endl;
                    cin >> room;
                    totr += room; //Number of rooms in each floor added to Total Room (totr)
                    cout << "How many rooms are occupied on this floor?" << endl;
                    cin >> numocc;
                    toto += numocc; //Number of rooms occupied in each floor added to (toto)
                }
                totuo = totr - toto; //Total Unoccupied room
                cout << fixed << setprecision(2);
                rate = toto / totr;
                //Display Result
                cout << "The total number of room is " << totr << endl;
                cout << "The total number of occupied room is " << toto << endl;
                cout << "Rooms unoccupied is " << totuo << endl;
                cout << rate * 100 << "% rate of room occupied" << endl;
                break;
            }
            case 10:
            {
                //Declare Variables
                float avg, year, tinch = 0, inch, mon;
                //# of Years
                cout << "How many Years?" << endl;
                cin >> year;
                //How many month
                mon = 12 * year;
                for (float y = 1; y <= year; y++) {
                    for (float m = 1; m <= 12; m++) {
                        cout << "Inches of rainfall" << endl;
                        cin >> inch;
                        tinch += inch;
                        //Average rainfall per month
                        avg = tinch / mon;
                    }
                }
                //Display Result
                //# of months
                cout << "Month " << mon << endl;
                //Total inches of rainfall
                cout << "Total inches of rainfall is " << tinch << endl;
                //Average rain fall per month
                cout << setprecision(2) << fixed << endl;
                cout << "Average rainfall per month is " << avg << endl;
                break;
            }
            case 11:
            {
                //Declare Variables
                float cost, markup, last;
                //Input the item wholesale cost
                cout << "Price of item's wholesale cost? ";
                cin >> cost;
                //Input the markup percentage
                cout << "What is the markup percentage? ";
                cin >> markup;
                cout << endl;
                calculateRetail(cost, markup, last);
                break;
            }
            case 12:
            {
                //Declare Variables
                float length, width, area, result;
                length = getLength(length);
                width = getWidth(width);
                area = getArea(length, width);
                result = displayArea(length, width, area);
                break;
            }
            case 13:
            {
                //Declare Variables
                float Northeast, Southeast, Northwest, Southwest, sales;
                //Northeast
                cout << "Northeast" << endl;
                Northeast = getSales(sales);
                //Southeast
                cout << "Southeast" << endl;
                Southeast = getSales(sales);
                //Northwest
                cout << "Northwest" << endl;
                Northwest = getSales(sales);
                //Southwest
                cout << "Southwest" << endl;
                Southwest = getSales(sales);
                //Highest Division, and Result
                findHighest(Northeast, Southeast, Northwest, Southwest);
                break;
            }
            case 14:
            {
                //Declare Variable
                int North, South, East, West, Central, num;
                //Function to Input
                cout << "North" << endl;
                North = getNumAccidents(num);
                cout << "South" << endl;
                South = getNumAccidents(num);
                cout << "East" << endl;
                East = getNumAccidents(num);
                cout << "West" << endl;
                West = getNumAccidents(num);
                cout << "Central" << endl;
                Central = getNumAccidents(num);
                //Function to find lowest amount of accidents
                findLowest(North, South, East, West, Central);
                break;
            }
            case 15:
            {
                //Declare Variable
                float time;
                //Loop time from 1 ~ 10 sec
                for (time = 1; time <= 10; time++) {
                    cout << time << " sec";
                    fallingDistance(time);
                }
                break;
            }
            case 16:
            {
                //Declare Variables
                float mass, veloc, result;
                //Input Mass
                cout << "The mass in kilograms ";
                cin >> mass;
                //Input Velocity
                cout << "The velocity in meters/sec ";
                cin >> veloc;
                //Function
                result = kineticEnergy(mass, veloc);
                cout << "The objects KE is " << result << endl;
                break;
            }
            case 17:
            {
                //Declare Variables
                int count;
                //Loop
                for (count = 0; count <= 20; count++) {
                    cout << "Fahrenheit of " << count << endl;
                    celsius(count);
                }
                break;
            }
            case 18:
            {
                //Declare Variable
                int num;
                //Toss coin how many times?
                cout << "How many times do you want to toss a coin? ";
                cin >> num;
                //Function Coin Toss
                coinToss(num);
                break;
            }
            case 19:
            {
                //Declare Variables
                float f, i, yer;
                //Input Future Value
                cout << "Future Value ";
                cin >> f;
                //Input annual interest rate
                cout << "Annual interest rate ";
                cin >> i;
                //Input Year
                cout << "How many years? ";
                cin >> yer;
                //Function
                presentValue(f, i, yer);
                break;
            }
            case 20:
            {
                //Declare Variable
                float test1, test2, test3, test4, test5, lowest;
                //Function Test Score
                getScore(test1);
                getScore(test2);
                getScore(test3);
                getScore(test4);
                getScore(test5);
                //Lowest Score Function
                lowest = findLowest(test1, test2, test3, test4, test5);
                //Format
                cout << setprecision(2) << fixed;
                //Average Function
                calcAverage(test1, test2, test3, test4, test5, lowest);
                break;
            }
            default:
            {
                cout << "Exit?" << endl;
                loop = false;
                break;
            }
        };
    } while (loop); //Upper do-while
    return 0;
}

void calculateRetail(float icost, float percent, float retail) {
    //Format
    cout << setprecision(2) << fixed;
    //Calculation
    retail = icost * (percent / 100) + icost;
    //Display
    cout << "If an item's wholesale cost is " << icost << " and its markup" << endl;
    cout << "percentage is " << percent << "%, then the item's retail " << endl;
    cout << "price is " << retail << endl;
}

float getLength(float length) {
    //Enter Length
    cout << "What is the length of the rectangle? ";
    cin >> length;
    return length;
}

float getWidth(float width) {
    //Enter Width
    cout << "What is the width of the rectangle? ";
    cin >> width;
    return width;
}

float getArea(float length, float width) {
    //Calculate the area of the rectangle
    float area = length*width;
    return area;
}

float displayArea(float length, float width, float area) {
    cout << endl;
    cout << "Result" << endl;
    //Format
    cout << setprecision(2) << fixed;
    //Display
    cout << "The length of the rectangle is " << length << endl;
    cout << "The width of the rectangle is " << width << endl;
    cout << "The area of the rectangle is " << area << endl;
}

float getSales(float sales) {
    //Input Sales for Division
    cout << "What is the division's quarterly sales figure? ";
    cin >> sales;
    if (sales < 0) {
        cout << "Enter a positive number" << endl;
        return 0;
    }
    return sales;
}

void findHighest(float NE, float SE, float NW, float SW) {
    //Format
    cout << setprecision(2) << fixed << endl;
    if (NE > SE && NE > NW) {
        if (NE > SW) {
            cout << "NorthEast had the greatest sales of $" << NE << endl;
        }
    }
    if (SE > NE && SE > NW) {
        if (SE > SW) {
            cout << "SouthEast had the greatest sales of $" << SE << endl;
        }
    }
    if (NW > NE && NW > SE) {
        if (NW > SW) {
            cout << "NorthWest had the greatest sales of $" << NW << endl;
        }
    }
    if (SW > NE && SW > SE) {
        if (SW > NW) {
            cout << "SouthWest had the greatest sales of $" << SW << endl;
        }
    }
}

int getNumAccidents(int crash) {
    //Input # of accidents in a region
    do {
        cout << "Enter the number of accidents (Positive Number) ";
        cin >> crash;
    } while (crash < 0);
    return crash;
}

void findLowest(int n, int s, int e, int w, int c) {
    cout << setprecision(2) << fixed << endl;
    if (n < s && n < e && n < w && n < c) {
        cout << "North has the lowest amount of accidents at " << n << endl;
    }
    if (s < n && s < e && s < w && s < c) {
        cout << "South has the lowest amount of accidents at " << s << endl;
    }
    if (e < n && e < s && e < w && e < c) {
        cout << "East has the lowest amount of accidents at " << e << endl;
    }
    if (w < n && w < s && w < e && w < c) {
        cout << "West has the lowest amount of accidents at " << w << endl;
    }
    if (c < n && c < s && c < e && c < w) {
        cout << "Central has the lowest amount of accidents at " << c << endl;
    }
}

float fallingDistance(float t) {
    //Declare distance
    float d;
    //Format
    cout << setprecision(2) << fixed << endl;
    //Find distance
    d = ((.5)*9.8)*(t * t);
    cout << "The distance is " << d << " meters" << endl;
    cout << endl;
    return d;
}

float kineticEnergy(float m, float v) {
    //Declare Kinetic Energy
    float KE;
    //Format
    cout << setprecision(2) << fixed << endl;
    //Calculation
    KE = ((.5) * m)*(v * v);
    return KE;
}

float celsius(float f) {
    //Declare Variable
    float c;
    //Format
    cout << setprecision(2) << fixed;
    //Celsius Calculation from Fahrenheit
    c = (5 / 9.0)*(f - 32); //9.0 because dividing by integers gives 0
    cout << "Celsius equivalent is " << c << endl;
    cout << endl;
    return c;
}

short coinToss(short n) {
    //Set the random number seed
    srand(static_cast<unsigned int> (time(0)));
    //Declare variable
    short r;
    //Loop
    for (int count = 0; count <= n; count++) {
        //Declare Variable
        short r;
        r = rand() % 2 + 1;
        if (r == 1) {
            cout << "Heads ";
        } else {
            cout << "Tails ";
        }

        cout << r << endl;
    }

}

float presentValue(float fv, float air, float years) {
    //Declare Variable
    float pv;
    //Calculations
    pv = (fv) / (pow(1 + (air / 100), years));
    cout << "Present Value has to be $" << pv << endl;
    return pv;
}

void getScore(float &score) {
    cout << "Enter the test score ";
    cin >> score;
    //Not accept score above 100, below 0
    while (score < 0 || score > 100) {
        cout << "Enter test score between 0~100 ";
        cin >> score;
    }
}

void calcAverage(float c1, float c2, float c3, float c4, float c5, float low) {
    //Declare Variable
    float avg;
    //Average
    avg = ((c1 + c2 + c3 + c4 + c5) - low) / 4.0;
    cout << "Average test score is " << avg << endl;
}

float findLowest(float t1, float t2, float t3, float t4, float t5) {
    //Declare Variable
    float low = t1;
    if (t2 < low) {
        low = t2;
    }
    if (t3 < low) {
        low = t3;
    }
    if (t4 < low) {
        low = t4;
    }
    if (t5 < low) {
        low = t5;
    }
    cout << endl;
    cout << "Lowest test score is " << low << endl;
    return low;
}