/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on January 7, 2014, 4:16 PM
 * Gaddis Prob 1 Chap 2
 * Add 62 + 99
 */

//System Libraries
#include <iostream>
using namespace std;

//System Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare variables
    float numone, numtwo, total;
    //Store integer 62
    numone=62;
    //Store integer 99
    numtwo=99;  
    //Calculate the Sum of Two Numbers
    total=numone+numtwo;
    //Output the Result
    cout<<total<<endl;
    //Exit Stage Right
    return 0;
}

