/* 
 * File:   main.cpp
 * Author: Andrew Kim
 * Created on February 3, 2014, 4:37 PM
 * Project 2 - Survival Text Adventure  
 */

//System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
using namespace std;

//Global Constants

//Function Prototypes
void title(bool &,int &,int &);
int play();
void area1(bool &,short,int &,char [][4]);
void area2(bool &,short &,int &,char [][4]);
void area3(short,int &,char [][4]);
void area4(bool &,short &,int &,char [][4]);
void area5(short,int &,char [][4]);
void area6(bool &,short &,int &,char [][4]);
void area7(int &,bool &,bool &,short &,char [][4]);
void area8(int &,bool &,short &,const int,int [],char [][4]);
void death(bool &,int);
void ending(bool &,short,int,int);
void showArray(char [][4],int);

//Execution Begins Here
int main(int argc, char** argv){
    //Declare Variable
    int plocate=0;//Reference for location
    bool runprg=1;//Runs the program, ends if pressed wrong
    bool picka2=0;//Area 2 If item picked up
    bool picka6=0;//Area 6 if item picked up
    bool givea4=0;//Area 4 If supply stolen
    bool kill7=0;//Area 7 if the place fell
    bool tun8=0;//Area 8 if tunnel is used
    short supply=0;//Supply to score how to end
    int input=0;//Which character it is
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    //1 Dimensional Array Requirement (Tunnel)
    const int SIZE=7;
    int tunnel[SIZE]={1,2,3,4,5,6,7};
    //2 Dimensional Array Requirement (Map)
    char X=88,O=79,E=69;
    char map[3][4]={{88,79,79,79},
                          {69,79,79,79},
                          {88,79,79,88}};
    //Start of Game
    title(runprg,plocate,input);
    //Game Loop
    do{
        area1(picka2,supply,plocate,map);
        area2(picka2,supply,plocate,map);
        area3(supply,plocate,map);
        area4(givea4,supply,plocate,map);
        area5(supply,plocate,map);
        area6(picka6,supply,plocate,map);
        area7(plocate,runprg,kill7,supply,map);
        area8(plocate,tun8,supply,SIZE,tunnel,map);
        ending(runprg,supply,plocate,input);
        death(runprg,plocate);
    }while(runprg==1);//When runprg==0 it stops the loop;
    return 0;
}

void showArray(char array[][4],int rows){
    for(int x=0;x<3;x++){
        for(int y=0;y<4;y++){
            cout<<setw(2)<<array[x][y]<<" ";
        }
        cout<<endl;
    }
}

void ending(bool &runprg,short supply,int plocate,int input){
    if(plocate==98&&input==1){
        if(supply==0){
            cout<<"You left the city with no supplies. You died of"<<endl;
            cout<<"hunger when unable to find food in nearby buildings"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>0&&supply<=5){
            cout<<"You took a few supplies on your journey down the road"<<endl;
            cout<<"After weeks of walking you noticed you have no more food left"<<endl;
            cout<<"Few days later..."<<endl;
            cout<<"You see a town in a distance but you couldn't"<<endl;
            cout<<"walk no longer, you fell and slowly died of hunger."<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>5){
            cout<<"You had readied yourself for a long journey down the road"<<endl;
            cout<<"Weeks has passed.... as you gathered for supplies anytime you can"<<endl;
            cout<<"In a distance you see a town with farms being taken care of."<<endl;
            cout<<"You slowly introduced yourself as non threatening as you can"<<endl;
            cout<<"They welcomed you into their town"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
    }
    if(plocate==98&&input==2){
        if(supply==0){
            cout<<"You left the city with no supplies. You ran as fast"<<endl;
            cout<<"as you can. Having the ability to run didn't help at all."<<endl;
            cout<<"When unable to run no more, your body gave up and you fell"<<endl;
            cout<<"and died of hunger"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>0&&supply<=5){
            cout<<"You took a few supplies on your journey down the road"<<endl;
            cout<<"After weeks of running day after day you noticed you"<<endl;
            cout<<"have no more food left"<<endl;
            cout<<"Few days later..."<<endl;
            cout<<"You see a town in a distance but you couldn't"<<endl;
            cout<<"move after losing all your energy, you fell and slowly died of hunger."<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
        else if(supply>5){
            cout<<"You had readied yourself for a long journey down the road"<<endl;
            cout<<"A week has passed....."<<endl;
            cout<<"In a distance you see a town with farms being taken care of."<<endl;
            cout<<"You slowly introduced yourself as non threatening as you can"<<endl;
            cout<<"They welcomed you into their town"<<endl;
            cout<<"The End"<<endl;
            runprg=0;
        }
    }
}

void death(bool &runprg,int plocate){
    if(plocate==99){
        cout<<"You have died"<<endl;
        cout<<"Game Over"<<endl;
        runprg=0;
    }
}

void area8(int &plocate,bool &tun8,short &supply,const int SIZE,int tun[],char map[][4]){
    int input1=0;
    int input2=0;
    if(plocate==8){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[0][1]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        if(tun8==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You came upon the hillside with a tunnel."<<endl;
            cout<<"The tunnel may lead somewhere."<<endl;
            cout<<"1. Enter the tunnel"<<endl;
            cout<<"2. Turn Back"<<endl;
            cin>>input1;
            if(input1==1){
                cout<<"You entered the dark tunnel and can hear the area"<<endl;
                cout<<"crumble behind you."<<endl;
                cout<<"You came out of the tunnel unscathed."<<endl;
                cout<<"You look around your surroundings"<<endl;
                //Declare small variable
                //Random number to choose area
                int chance=rand()%7+1;
                for(int j=0;j<SIZE;j++){
                    if(tun[j]==chance){
                        plocate=chance;
                        tun8=1;
                        map[0][1]=79;
                    }
                }
            }
            else if(input1==2)plocate=5;map[0][1]=79;
        }
        if(tun8==1&&plocate==8){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You came upon the hillside"<<endl;
            cout<<"The tunnel collapsed"<<endl;
            cout<<"1. Turn Back"<<endl;
            cin>>input2;
            if(input2==1)plocate=5;map[0][1]=79;
        }
    }
}

void area7(int &plocate,bool &runprg,bool &kill7,short &supply,char map[][4]){
    unsigned int input=0;
    if(plocate==7){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[2][1]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        if(kill7==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"As you walk along the road you can feel the ground shaking"<<endl;
            cout<<"What will you do"<<endl;
            cout<<"1. Back away"<<endl;
            cout<<"2. Run forward"<<endl;
            cin>>input;
            if(input==1){
                cout<<"You can see the road ahead breaking apart from"<<endl;
                cout<<"a rupture in the ground. If you had went across"<<endl;
                cout<<"you would have fallen to your death"<<endl;
                cout<<endl;
                kill7=1;plocate=7;map[2][1]=79;
            }
            else if(input==2){
                cout<<"You try to run across but the cracks on the road"<<endl;
                cout<<"spreads apart and you fell through the cracks"<<endl;
                plocate=99;map[2][1]=79;
            }
        }
        else if(kill7==1){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You looked at the wreckage in front of you."<<endl;
            cout<<"Decided the road in front is impassable"<<endl;
            cout<<"1. Turn Back"<<endl;
            cin>>input;
            cout<<endl;
            if(input==1)plocate=5;map[2][1]=79;
        }
    }
}

void area6(bool &picka6,short &supply,int &plocate,char map[][4]){
    long input1=0;//For the inputs
    if(plocate==6){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[0][2]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        if(picka6==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"After coming out of the roots, you see a chest"<<endl;
            cout<<"1. Try to open Chest (Get 6 supplies)"<<endl;
            cout<<"2. Go back"<<endl;
            cout<<endl;
            cin>>input1;
            if(input1==1){
                cout<<"Chest is locked try giving it a few kicks (3)"<<endl;
                cout<<"1. Kick"<<endl;
                for(int i=0;i<3;i++){
                    cin>>input1;
                    if(input1==1){
                        cout<<"Kicked"<<endl;
                    }
                }
                supply=supply+6;
                picka6=1;
            }
            else if(input1==2)plocate=3;map[0][2]=79;
        }
        else if(picka6==1){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"You looked around for any other hidden supplies."<<endl;
            cout<<"The place seems cleaned out"<<endl;
            cout<<"1. Go back"<<endl;
            cout<<endl;
            cin>>input1;
            if(input1==1)plocate=3;map[0][2]=79;
        }
    }
}


void area5(short supply,int &plocate,char map[][4]){
    unsigned long input=0;//For the inputs
    if(plocate==5){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[1][1]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<"Your current supply = "<<supply<<endl;
        cout<<"You find the road which leads out of the city"<<endl;
        cout<<"Are you sure you wanna leave now?"<<endl;
        cout<<"1. Leave the city (Ends)"<<endl;
        cout<<"2. Go South"<<endl;
        cout<<"3. Go North"<<endl;
        cout<<"4. Go East"<<endl;
        cout<<endl;
        cin>>input;
        if(input==1){plocate=98;map[1][1]=79;}
        else if(input==2){plocate=7;map[1][1]=79;}
        else if(input==3){plocate=8;map[1][1]=79;}
        else if(input==4){plocate=3;map[1][1]=79;}
    }
}

void area4(bool &givea4,short &supply,int &plocate,char map[][4]){
    unsigned short input=0;//For the inputs from 0 - 65535
    const unsigned short DEMAND=2;//Always demands 2 supplies in this function
    if(plocate==4){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[2][2]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        if(givea4==0){
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"There stands a member of a gang, He wants your supplies"<<endl;
            cout<<"He demands 2 supplies if you don't you will die"<<endl;
            cout<<"1. Give 2 supplies"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1){
                supply=supply-DEMAND;
                givea4=1;
            }
            if(supply<2){
                cout<<"You didn't have enough supplies, you have been shot to"<<endl;
                cout<<"death."<<endl;
                plocate=99;map[2][2]=79;
            }
        }
        else if(givea4==1){
            cout<<"Supply remaining = "<<supply<<endl;
            cout<<"After giving away your supply he seems to let you live"<<endl;
            cout<<"You looked around and you see the area blocked with no"<<endl;
            cout<<"other way out so you turned around"<<endl;
            cout<<"1. Go back"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1)plocate=3;map[2][2]=79;
        }
    }
}

void area3(short supply,int &plocate,char map[][4]){
    int input=0;//For the inputs
    while(plocate==3){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[1][2]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<"Your current supply = "<<supply<<endl;
        cout<<"The path to the north of you is blocked by a giant root"<<endl;
        cout<<"1. Take a closer look at the root towards the North"<<endl;
        cout<<"2. Go West"<<endl;
        cout<<"3. Go Back"<<endl;
        cout<<"4. Go South"<<endl;
        cout<<endl;
        cin>>input;
        if(input==4){plocate=4;map[1][2]=79;}
        else if(input==2){plocate=5;map[1][2]=79;}
        else if(input==3){plocate=1;map[1][2]=79;}
        else if(input==1){
            cout<<"Upon closer inspection with the root you find a way through"<<endl;
            plocate=6;map[1][2]=79;
        }
    }
}

void area2(bool &picka2,short &supply,int &plocate,char map[][4]){
    int input=0;//For the inputs
    float x=294.23;
    ifstream inputFile;
    string word;
    inputFile.open("graffiti.txt");
    if(plocate==2){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[0][3]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        if(picka2==0){//Not picked up supply
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"As you continue to walk you find out this is a deserted city"<<endl;
            cout<<"You reached an area which is blocked off by boulders."<<endl;
            cout<<"The boulders has graffiti marks which reads "<<setprecision(2)<<fixed<<x<<endl;
            inputFile>>word;
            cout<<word<<endl;
            cout<<"It seems to be random graffiti markings"<<endl;
            cout<<"Some supplies are found beside the boulders"<<endl;
            cout<<"1. Head Back"<<endl;
            cout<<"2. Pick up Supplies (+5)"<<endl;
            cout<<"3. Write on the wall"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1){plocate=1;map[0][3]=79;}
            else if(input==2){
                cout<<"You picked up some supplies which were hidden"<<endl;
                supply=supply+5;
                picka2=1;//Item Picked up
            }
            else if(input==3){
                ofstream outputFile;
                outputFile.open("graffiti.txt");
                int input2=0;
                cout<<"You cleaned up a spot to write"<<endl;
                cout<<"What will you write?"<<endl;
                cout<<"1. gibberish"<<endl;
                cout<<"2. Hello!!"<<endl;
                cout<<"3. Supplies!"<<endl;
                cin>>input2;
                if(input2==1){
                    outputFile<<"asdjdfhgjhsdj"<<endl;
                }
                else if(input2==2){
                    outputFile<<"Hello!!"<<endl;
                }
                else if(input2==3){
                    outputFile<<"Supplies!"<<endl;
                }
                outputFile.close();
            }
        }
        else if(picka2==1){//When item is picked up go to this block
            cout<<"Your current supply = "<<supply<<endl;
            cout<<"The writing on the wall says"<<endl;
            inputFile>>word;
            cout<<word<<endl;
            cout<<"The boulder still block the path"<<endl;
            cout<<"1. Head Back"<<endl;
            cout<<"2. Write on the wall"<<endl;
            cout<<endl;
            cin>>input;
            if(input==1){plocate=1;map[0][3]=79;}
            else if(input==2){
                ofstream outputFile;
                outputFile.open("graffiti.txt");
                int input2=0;
                cout<<"You cleaned up a spot to write"<<endl;
                cout<<"What will you write?"<<endl;
                cout<<"1. gibberish"<<endl;
                cout<<"2. Hello!!"<<endl;
                cout<<"3. Supplies!"<<endl;
                cin>>input2;
                if(input2==1){
                    outputFile<<"asdjdfhgjhsdj"<<endl;
                }
                else if(input2==2){
                    outputFile<<"Hello!!"<<endl;
                }
                else if(input2==3){
                    outputFile<<"Supplies!"<<endl;
                }
                outputFile.close();
            }
        }
        inputFile.close();
    }
    
}

void area1(bool &picka2,short supply,int &plocate,char map[][4]){//First area
    int input=0;//For the inputs
    if(plocate==1){
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        cout<<setw(30)<<"MAP"<<endl;
        map[1][3]=90;
        showArray(map,3);
        cout<<"X = Blocked"<<endl;
        cout<<"O = Area"<<endl;
        cout<<"E = Ending"<<endl;
        cout<<"Z = Current Position"<<endl;
        cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
        do{
            cout<<"Your current supply = "<<supply<<endl;     
            cout<<"You are standing around buildings which seems to be deserted."<<endl;
            cout<<"You look around the path it seems to only go North or West"<<endl;
            cout<<"1. Go North"<<endl;
            cout<<"2. Go West"<<endl;
            cout<<endl;
            cin>>input;
            switch(input){
            case 1:     plocate=2;map[1][3]=79;break;
            case 2:     plocate=3;;map[1][3]=79;break;
            }
        }while(plocate==1);
    }
}

int play(){
    //Declare small variable
    int input;
    string line;
    ifstream myfile("readinme.txt");
    if(myfile.is_open()){
        while(getline(myfile,line)){
            cout<<line<<endl;
        }
        myfile.close();
    }
    cin>>input;
    return input;
}

void title(bool &runprg,int &plocate,int &input){
    char p=80;//char p=80 is P
    cout<<setw(20)<<"Survival Text Adventure"<<endl;//Sets Format
    cout<<endl;
    cout<<endl;
    cout<<"1. "<<p<<"lay"<<endl;
    cout<<"2. Exit"<<endl;
    cin>>input;
    if(input==1){
        play();//Starts the game
        plocate=1;//Sends to starting area
    }
    else{
        runprg=0;//exits
    }
    return;
}
